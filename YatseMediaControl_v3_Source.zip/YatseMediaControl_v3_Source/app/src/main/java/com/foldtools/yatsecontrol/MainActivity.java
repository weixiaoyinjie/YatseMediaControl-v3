package com.foldtools.yatsecontrol;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Zero-dependency Fold6 control UI.
 * Yatse receiver and supported command names: https://yatse.tv/wiki/yatse-api
 * Direct Kodi RPC is optional and is used ONLY for precise seeking and relative volume.
 */
public final class MainActivity extends Activity {
    private static final String YATSE = "org.leetzone.android.yatsewidgetfree";
    private static final String RECEIVER = "tv.yatse.api.ApiReceiver";
    private static final String ACTION_MEDIA = "tv.yatse.api.MEDIA_COMMAND";
    private static final String PREFS = "yatse_control_v3";
    private static final String KEYSTORE = "YatseControl_V3_Password";
    private static final String CHANNEL = "return_to_controller";
    private static final int NOTIFICATION_ID = 7341;
    private static final int REQUEST_NOTIFY = 41;
    private static final int BG = Color.rgb(17, 23, 34);
    private static final int CARD = Color.rgb(31, 42, 59);
    private static final int BTN = Color.rgb(42, 57, 75);
    private static final int ACCENT = Color.rgb(105, 221, 193);
    private static final int TEXT = Color.rgb(244, 249, 251);
    private static final int MUTED = Color.rgb(171, 188, 201);
    private static final int WARNING = Color.rgb(247, 184, 101);
    private static final int RED = Color.rgb(102, 49, 55);
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private LinearLayout content, root, navBar;
    private ScrollView scroll;
    private TextView pageTitle;
    private EditText hostInput, portInput, userInput, passwordInput;
    private String currentTab = "home";
    private SharedPreferences prefs;
    private final String[][] views = {
        {"遥控器", "yatse://command/show/remote"},
        {"音乐库", "yatse://command/browse/music"},
        {"图片库", "yatse://command/browse/pictures"},
        {"文件 / SMB", "yatse://command/browse/files"},
        {"电影库", "yatse://command/browse/movies"},
        {"电视剧库", "yatse://command/browse/tvshows"},
        {"音量滑块", "yatse://command/show/volume_slider"},
        {"选择设备", "yatse://command/show/select_host"},
        {"电视直播", "yatse://command/browse/pvr_tv"},
        {"电台", "yatse://command/browse/pvr_radios"},
        {"语音命令", "yatse://command/voicecommand/start"}
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, ins) -> {
                android.graphics.Insets bars = ins.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(0, bars.top, 0, bars.bottom);
                return WindowInsets.CONSUMED;
            });
        } else {
            root.setFitsSystemWindows(true);
        }
        setContentView(root);
        makeHeader();
        scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(10), dp(14), dp(22));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setPadding(dp(6), dp(7), dp(6), dp(10));
        navBar.setBackgroundColor(CARD);
        root.addView(navBar, new LinearLayout.LayoutParams(-1, dp(69)));
        if (prefs.getBoolean("return_notification", false)) showReturnNotification();
        showTab("home");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        showTab("home");
    }

    private void makeHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(18), dp(11), dp(13), dp(10));
        TextView title = txt("Yatse 影音控制", 20, true, TEXT);
        h.addView(title, new LinearLayout.LayoutParams(0, dp(42), 1f));
        title.setGravity(Gravity.CENTER_VERTICAL);
        TextView home = pill("⌂ 控制首页", ACCENT, BG);
        h.addView(home, new LinearLayout.LayoutParams(-2, dp(40)));
        home.setOnClickListener(v -> showTab("home"));
        root.addView(h);
        pageTitle = txt("", 13, false, MUTED);
        pageTitle.setPadding(dp(18), 0, dp(18), dp(7));
        root.addView(pageTitle);
    }

    private int dp(float n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private TextView txt(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true);
        return t;
    }

    private GradientDrawable rounded(int c, int r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(c);
        d.setCornerRadius(dp(r));
        return d;
    }

    private TextView pill(String name, int bg, int fg) {
        TextView b = txt(name, 13, true, fg);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), dp(7), dp(12), dp(7));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), rounded(bg, 13), null));
        b.setClickable(true);
        b.setFocusable(true);
        b.setContentDescription(name);
        return b;
    }

    private void heading(String text) {
        TextView t = txt(text, 17, true, TEXT);
        t.setPadding(dp(4), dp(17), 0, dp(10));
        content.addView(t);
    }
    private void note(String s) {
        TextView t = txt(s, 13, false, MUTED);
        t.setPadding(dp(5), dp(3), dp(5), dp(12));
        t.setLineSpacing(dp(3), 1f);
        content.addView(t);
    }
    private void button(LinearLayout parent, String s, Runnable action, int color) {
        TextView b = pill(s, color, TEXT);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(60), 1f);
        p.setMargins(dp(4), dp(4), dp(4), dp(4));
        parent.addView(b, p);
        b.setOnClickListener(v -> action.run());
    }
    private void pair(String l, Runnable a, String r, Runnable b) {
        pairColor(l, a, BTN, r, b, BTN);
    }
    private void pairColor(String l, Runnable a, int lColor, String r, Runnable b, int rColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        content.addView(row, new LinearLayout.LayoutParams(-1, -2));
        button(row, l, a, lColor);
        button(row, r, b, rColor);
    }
    private void single(String s, Runnable a, int color) {
        LinearLayout row = new LinearLayout(this);
        content.addView(row, new LinearLayout.LayoutParams(-1, -2));
        button(row, s, a, color);
    }
    private void send(String command) {
        if (!yatsePresent()) {
            toast("没有检测到 Yatse，请先安装并完成 Kodi 配对");
            return;
        }
        Intent i = new Intent(ACTION_MEDIA);
        i.setComponent(new ComponentName(YATSE, RECEIVER));
        i.putExtra("COMMAND", command);
        try {
            sendBroadcast(i);
            toast("已发送到 Yatse：" + command + "（请看 Kodi 是否响应）");
        } catch (Exception e) {
            toast("发送失败：" + e.getClass().getSimpleName());
        }
    }
    private boolean yatsePresent() {
        try { getPackageManager().getPackageInfo(YATSE, 0); return true; }
        catch (PackageManager.NameNotFoundException e) { return false; }
    }
    private void openUri(String uri) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        i.setPackage(YATSE);
        try { startActivity(i); }
        catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uri))); }
            catch (Exception x) { toast("Yatse 页面无法打开，请检查是否已安装"); }
        }
    }
    private void confirm(String title, String body, Runnable job) {
        new AlertDialog.Builder(this)
            .setTitle(title).setMessage(body)
            .setNegativeButton("取消", (d,w) -> {})
            .setPositiveButton("确认发送", (d,w) -> job.run())
            .show();
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }

    private void showTab(String tab) {
        currentTab = tab;
        content.removeAllViews();
        scroll.scrollTo(0, 0);
        switch (tab) {
            case "media": pageTitle.setText("11 个 Yatse 官方 URI · 打开对应页面"); renderMedia(); break;
            case "play": pageTitle.setText("播放与精确跳转 · Kodi 音量"); renderPlayback(); break;
            case "direction": pageTitle.setText("电视 Kodi 遥控 · Home 与返回独立"); renderDirection(); break;
            case "cec": pageTitle.setText("实验功能 · 可能不支持 Android TV CEC"); renderCec(); break;
            case "settings": pageTitle.setText("Kodi HTTP 可选 · 返回入口通知"); renderSettings(); break;
            default: pageTitle.setText("Fold6 专用 · Kodi / Yatse 控制中心"); renderHome(); break;
        }
        makeNav();
    }
    private void makeNav() {
        navBar.removeAllViews();
        String[][] tabs = {{"home","首页"}, {"media","媒体"}, {"play","播放"}, {"direction","导航"}, {"cec","CEC"}, {"settings","设置"}};
        for (String[] t : tabs) {
            boolean active = currentTab.equals(t[0]);
            TextView b = pill(t[1], active ? ACCENT : CARD, active ? BG : MUTED);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1f);
            p.setMargins(dp(1), 0, dp(1), 0);
            navBar.addView(b, p);
            b.setOnClickListener(v -> showTab(t[0]));
        }
    }

    private void renderHome() {
        heading("常用操作");
        pairColor("▶  播放 / 暂停", () -> send("playpause"), 0xFF24544C,
                  "■  停止", () -> send("stop"), BTN);
        pair("⟵  Kodi 返回", () -> send("back"), "⌂  Kodi Home", () -> send("home"));
        pair("◀◀  快退", () -> send("rewind"), "快进  ▶▶", () -> send("forward"));
        pair("上一首", () -> send("previous"), "下一首", () -> send("next"));
        heading("一键打开 Yatse 页面");
        pair("Kodi 遥控器", () -> openUri(views[0][1]), "音乐库", () -> openUri(views[1][1]));
        pair("图片库", () -> openUri(views[2][1]), "SMB 文件", () -> openUri(views[3][1]));
        pair("电影库", () -> openUri(views[4][1]), "音量滑块", () -> openUri(views[6][1]));
        heading("明确区分两个首页");
        note("右上角「控制首页」= 返回本 App。\n「Kodi Home」= 通过 Yatse 控制 TV 上的 Kodi。\n从 Yatse 返回不方便，可在设置中开启通知栏返回快捷入口。\nYatse 广播已发送不等于 Kodi 已响应。");
        if (!yatsePresent()) note("⚠ 尚未检测到 Yatse；请安装后在 Yatse 中连接 Kodi。");
    }

    private void renderMedia() {
        heading("媒体库与遥控入口");
        for (int n=0; n<views.length; n+=2) {
            final int a=n;
            if (n+1<views.length) {
                final int b=n+1;
                pair(views[a][0], () -> openUri(views[a][1]), views[b][0], () -> openUri(views[b][1]));
            } else single(views[a][0], () -> openUri(views[a][1]), BTN);
        }
        note("URI 打开 Fold6 上的 Yatse 页面，不是直接让电视切换到 Kodi 对应页面。打开后可用系统返回键或通知入口回到本 App。");
        single("回到控制首页", () -> showTab("home"), 0xFF24544C);
    }
    private void renderPlayback() {
        heading("Yatse 官方媒体指令");
        pairColor("▶  播放", () -> send("play"), 0xFF24544C, "Ⅱ  暂停", () -> send("pause"), BTN);
        pair("播放 / 暂停", () -> send("playpause"), "停止", () -> send("stop"));
        pair("上一首", () -> send("previous"), "下一首", () -> send("next"));
        pair("快退（速度）", () -> send("rewind"), "快进（速度）", () -> send("forward"));
        pair("静音 / 取消", () -> send("togglemute"), "字幕", () -> send("subtitles"));
        single("打开 Yatse 音量滑块", () -> openUri(views[6][1]), BTN);
        heading("精确跳过秒数（Kodi JSON-RPC）");
        note("以下操作仅在「设置」配置 Kodi 局域网 HTTP 后可用。它们是真正的 -10 秒、+30 秒，而不是持续快退/快进速度。");
        pair("−10 秒", () -> seek(-10), "+30 秒", () -> seek(30));
        pair("−30 秒", () -> seek(-30), "+60 秒", () -> seek(60));
        heading("Kodi 相对音量（JSON-RPC）");
        pair("音量 −", () -> adjustVolume(false), "音量 +", () -> adjustVolume(true));
        note("注意：音量 +/− 调节 Kodi 音量，不等同于 S61B 的 HDMI CEC 音量控制。若电视端音量没变化，请使用 TV 实体遥控器或待后续验证的设备专用接口。");
    }
    private void renderDirection() {
        heading("Kodi 方向遥控");
        single("▲ 上", () -> send("up"), BTN);
        pair("◀ 左", () -> send("left"), "右 ▶", () -> send("right"));
        single("确认 / OK", () -> send("select"), 0xFF24544C);
        single("▼ 下", () -> send("down"), BTN);
        heading("返回与菜单");
        pairColor("⟵ Kodi 返回", () -> send("back"), BTN, "⌂ Kodi Home", () -> send("home"), 0xFF24544C);
        pair("菜单 / Context", () -> send("context"), "信息 / Info", () -> send("info"));
        pair("显示 / Display", () -> send("display"), "系统菜单", () -> send("system"));
        single("⌂ 返回本 App 控制首页", () -> showTab("home"), 0xFF24544C);
        note("Android 系统返回键在本 App 的其他控制页会先回到控制首页，不再直接退出。进入 Yatse 后，返回由 Yatse 与 Android 共同处理。");
    }
    private void renderCec() {
        heading("CEC 实验控制");
        note("这里发送的是 Yatse → Kodi 的 CEC API，不能保证 Android TV 上的 Kodi 能接管 HDMI-CEC。先观察 Google TV / PJD7720HD / S61B 有无实际响应。");
        pair("CEC 开", () -> send("cecon"), "CEC 切换", () -> confirm("测试 CEC 切换", "可能使某个 HDMI 设备开机或待机，也可能完全无效。确认测试？", () -> send("cectogglestate")));
        single("CEC 关（谨慎测试）", () -> confirm("确认发送 CEC 关", "这不是专门针对投影机的关机指令。如果 Kodi 的 CEC 适配器可用，可能影响连接设备。", () -> send("cecoff")), RED);
        heading("其他电源命令");
        single("Kodi 电源菜单 / Power", () -> confirm("测试 Power 命令", "Yatse power 命令不等同于 Google TV、投影机的独立开关。继续？", () -> send("power")), BTN);
        single("Kodi 关机 / Shutdown", () -> confirm("关闭 Kodi？", "可能导致 Kodi 退出或设备关机，只有确认必要时才发送。", () -> send("shutdown")), RED);
        note("重要：你之前实测 Google TV 实体遥控器能通过 CEC 控制投影机和 S61B，但这不证明本页指令可经 Kodi 转发。失败时不要反复按电源键，请等待设备状态稳定再检查。独立 RS-232 控制需要另一个实际测试通过的模块。");
    }

    private EditText field(String title, String value, int type) {
        TextView l = txt(title, 13, false, MUTED);
        l.setPadding(dp(6), dp(9), dp(3), dp(5));
        content.addView(l);
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(value);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setTextSize(16);
        e.setInputType(type);
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(rounded(BTN, 11));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.setMargins(dp(3), 0, dp(3), dp(4));
        content.addView(e, p);
        return e;
    }

    private void renderSettings() {
        heading("Kodi HTTP（可选）");
        note("填入电视上 Kodi 的局域网地址，仅供精确快进/快退、相对音量和连接测试。普通 Yatse 控制不需要这里的设置。HTTP 默认明文，请仅限可信内网使用。");
        hostInput = field("Kodi IP / 主机名", prefs.getString("host", ""), 1);
        portInput = field("Kodi HTTP 端口", prefs.getString("port", "8080"), 2);
        userInput = field("用户名（无则留空）", prefs.getString("user", ""), 1);
        passwordInput = field("密码（加密保存）", decryptStoredPassword(), 129);
        pair("保存设置", () -> saveConfig(true), "测试 Kodi 连接", () -> { if (saveConfig(false)) testRpc(); });
        heading("返回控制首页快捷方式");
        note("如果切到 Yatse 后手机返回键没有回到控制中心，可开启一条常驻通知：从通知栏点击「返回 Yatse 控制中心」就能一键回来。关闭后不再显示。此功能无需悬浮窗权限。");
        boolean enabled = prefs.getBoolean("return_notification", false);
        single(enabled ? "关闭通知栏返回入口" : "开启通知栏返回入口", () -> toggleReturnNotification(), enabled ? RED : 0xFF24544C);
        heading("使用说明");
        note("• 首先在 Yatse 中成功连接电视版 Kodi。\n• 本 App 需要 Yatse 10.9 或更新版本的广播接收器。\n• CEC 按钮属于实验项，能否控制音响和投影机取决于 Kodi / Android TV / HDMI 链路。\n• App 自身不上传任何数据，不带广告和账号服务。\n• 用户名保存在私有设置里，密码使用 Android Keystore AES-GCM 加密保存。");
        single("⌂ 返回控制首页", () -> showTab("home"), 0xFF24544C);
    }

    private boolean saveConfig(boolean show) {
        String h = hostInput.getText().toString().trim();
        String p = portInput.getText().toString().trim();
        String u = userInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        if (!h.isEmpty() && (h.contains("/") || h.contains("://") || h.contains(" ") || h.contains("@") || h.contains("?"))) {
            toast("主机只填 IP 或主机名，不要输入 http:// 或路径"); return false;
        }
        int port;
        try { port = Integer.parseInt(p); if (port<1 || port>65535) throw new IllegalArgumentException(); }
        catch (Exception e) { toast("端口应为 1～65535"); return false; }
        try {
            String[] saved = encryptPassword(password);
            prefs.edit().putString("host", h).putString("port", p)
                .putString("user", u).putString("iv", saved[0]).putString("pwd", saved[1]).apply();
            if (show) toast("设置已保存（密码已加密）");
            return true;
        } catch (Exception e) { toast("加密失败，未保存密码或设置"); return false; }
    }

    private SecretKey secretKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(KEYSTORE)) return (SecretKey) store.getKey(KEYSTORE, null);
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(KEYSTORE,
            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build());
        return gen.generateKey();
    }
    private String[] encryptPassword(String raw) throws Exception {
        if (raw.isEmpty()) return new String[]{"", ""};
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey());
        return new String[]{Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP),
            Base64.encodeToString(cipher.doFinal(raw.getBytes(StandardCharsets.UTF_8)), Base64.NO_WRAP)};
    }
    private String decryptStoredPassword() {
        try {
            String iv=prefs.getString("iv", ""), encrypted=prefs.getString("pwd", "");
            if (iv.isEmpty() || encrypted.isEmpty()) return "";
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey(),
                new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
            return new String(cipher.doFinal(Base64.decode(encrypted, Base64.NO_WRAP)), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }

    private JSONObject rpc(String method, JSONObject params) throws Exception {
        String host=prefs.getString("host", "");
        if (host.trim().isEmpty()) throw new IllegalStateException("先去设置输入 Kodi 的 IP");
        String port=prefs.getString("port", "8080");
        URL url = new URL("http://" + host + ":" + port + "/jsonrpc");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        try {
            c.setConnectTimeout(2500);
            c.setReadTimeout(3500);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            String user=prefs.getString("user", "");
            if (!user.isEmpty()) {
                String auth=user + ":" + decryptStoredPassword();
                String b64=Base64.encodeToString(auth.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                c.setRequestProperty("Authorization", "Basic " + b64);
            }
            JSONObject req=new JSONObject();
            req.put("jsonrpc", "2.0"); req.put("id", 1); req.put("method", method);
            if (params != null) req.put("params", params);
            byte[] bytes=req.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
            int status=c.getResponseCode();
            if (status != 200) throw new IllegalStateException("Kodi HTTP " + status);
            StringBuilder sb=new StringBuilder();
            try (InputStream in=c.getInputStream(); BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))) {
                String line; while ((line=br.readLine()) != null) sb.append(line);
            }
            JSONObject data = new JSONObject(sb.toString());
            if (data.has("error")) throw new IllegalStateException("Kodi RPC: " + data.getJSONObject("error").optString("message", "error"));
            return data;
        } finally { c.disconnect(); }
    }
    private interface Work { String run() throws Exception; }
    private void async(String task, Work w) {
        io.execute(() -> {
            try { String result = w.run(); runOnUiThread(() -> toast(task + "：" + result)); }
            catch (Exception e) {
                String message=e.getMessage();
                runOnUiThread(() -> toast(task + "失败：" + (message==null?"连接错误":message)));
            }
        });
    }
    private void testRpc() {
        async("连接测试", () -> rpc("JSONRPC.Ping",null).optString("result", "收到回复"));
    }
    private void adjustVolume(boolean increase) {
        async("Kodi 音量", () -> {
            JSONObject p=new JSONObject(); p.put("volume", increase ? "increment" : "decrement");
            return "当前 " + rpc("Application.SetVolume",p).getInt("result");
        });
    }
    private void seek(int seconds) {
        async("精确跳转", () -> {
            JSONObject active=rpc("Player.GetActivePlayers",null);
            JSONArray a=active.optJSONArray("result");
            if (a == null || a.length()==0) throw new IllegalStateException("当前没有正在播放的媒体");
            int player = a.getJSONObject(0).getInt("playerid");
            for (int i=0; i<a.length(); i++) {
                JSONObject item=a.getJSONObject(i);
                if ("video".equals(item.optString("type"))) {player=item.getInt("playerid"); break;}
            }
            JSONObject v=new JSONObject(); v.put("seconds", seconds);
            JSONObject p=new JSONObject(); p.put("playerid", player); p.put("value", v);
            rpc("Player.Seek",p);
            return seconds > 0 ? "+" + seconds + " 秒" : seconds + " 秒";
        });
    }

    private void toggleReturnNotification() {
        boolean enabled=prefs.getBoolean("return_notification",false);
        if (enabled) {
            prefs.edit().putBoolean("return_notification", false).apply();
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(NOTIFICATION_ID);
            showTab("settings");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFY);
            return;
        }
        prefs.edit().putBoolean("return_notification", true).apply();
        showReturnNotification();
        showTab("settings");
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request,permissions,results);
        if (request == REQUEST_NOTIFY) {
            if (results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) {
                prefs.edit().putBoolean("return_notification",true).apply();
                showReturnNotification();
                showTab("settings");
            } else toast("通知权限未允许，可以用桌面图标返回控制中心");
        }
    }
    private void showReturnNotification() {
        if (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"返回 Yatse 控制中心",NotificationManager.IMPORTANCE_LOW));
        Intent go=new Intent(this,MainActivity.class);
        go.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,0,go,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("返回 Yatse 控制中心")
            .setContentText("点此返回 Fold6 影音遥控首页")
            .setContentIntent(pi)
            .setOngoing(true)
            .setShowWhen(false)
            .build();
        nm.notify(NOTIFICATION_ID,n);
    }

    @Override public void onBackPressed() {
        if (!currentTab.equals("home")) showTab("home");
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }
}
