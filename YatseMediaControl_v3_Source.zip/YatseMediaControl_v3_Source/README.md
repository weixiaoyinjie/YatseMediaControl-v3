# Yatse 影音控制中心 V3 (Fold6 / Android)

一个不使用 WebView 的轻量原生 Android App，使用 Yatse 官方 Broadcast API 和 Kodi 官方 JSON-RPC。

## 已包含

- 11 个 Yatse 官方固定页面 URI：遥控器、音量滑块、选择设备、电影、电视剧、音乐、图片、文件、电视直播、电台、语音控制。
- `MEDIA_COMMAND`：播放/暂停、上一首/下一首、快退/快进、停止、静音、字幕、方向、选择、返回、Kodi Home、信息、菜单。
- CEC **实验区**：`cecon`、`cecoff`、`cectogglestate`、`power`，停机类命令需要二次确认；仅会发送到 Yatse 已连接的 Kodi，不保证 Google TV/投影机/S61B 支持。
- **两个 Home**：App「控制首页」和独立的「Kodi Home」按钮；系统返回键在其他控制页总是回到 App 首页。
- 可选常驻的「返回控制中心」通知：从 Yatse 退回控制中心的备用入口。Android 13+ 需要通知授权。
- 可选 Kodi JSON-RPC：**精确快退 10 秒、快进 30 秒**，相对 Kodi 音量加减，连接测试。关闭此功能时仍可使用 Yatse 命令。
- 本地保留 Kodi Host/端口/用户名/密码；密码经 Android Keystore AES-GCM 加密保存在私有 SharedPreferences。

## 编译

1. 打开 https://github.com/new 新建仓库，例如 `YatseMediaControl-v3`。
2. 解压 ZIP，把里面的**全部文件和隐藏的 `.github` 目录**上传到新仓库的根目录（勿额外套一层目录），提交到 `main` 分支。
3. GitHub → Actions → `Build Yatse Control APK` → `Run workflow`，或者 push 自动触发。
4. 完成后下载 Artifacts 中的 `YatseMediaControl-v3-debug-apk`，解压得到 `app-debug.apk`，安装 Fold6。
5. 也可用 Android Studio（JDK 17 / SDK 35）打开源代码直接 Build APK。

## 首次使用

1. 确保已安装 Yatse 10.9+，已经在 Yatse 中连接 TV 版 Kodi；先测试 App 中的 **播放/暂停** 和 **Kodi Home**。
2. 若需精确秒数和音量 +/−：在 Kodi → Settings → Services → Control 开启 HTTP 远程控制，在 App 的「设置」输入局域网 IP、HTTP 端口（常见 8080，但以实际为准）和凭证，点击「测试 Kodi 连接」。
3. 在「CEC 实验」先测试 `CEC 开`，再检查投影机是否响应。不要同时把 `CEC 关` 当成 TV/投影机专用关机按钮。
4. 若从 Yatse 返回主 App 不方便，可以在「设置」开启「通知栏返回入口」，从通知栏一键回到控制首页。

## API 与限制

Yatse 文档：https://yatse.tv/wiki/yatse-api
Kodi JSON-RPC：https://kodi.wiki/view/JSON-RPC_API/v12

- Yatse `MEDIA_COMMAND`：Action = `tv.yatse.api.MEDIA_COMMAND`，Receiver = `org.leetzone.android.yatsewidgetfree/tv.yatse.api.ApiReceiver`，Extra `COMMAND` 为指令名称。
- Android 发送广播不代表 Kodi 已接收/执行成功；需要观察 TV 响应。
- Kodi 精确 Seek 使用 `Player.GetActivePlayers` + `Player.Seek` 的 `value.seconds`，不是 Yatse 的前进速度命令。
- Kodi `Application.SetVolume` 调节 Kodi 自己的音量；**不保证**通过 Google TV CEC 改变 S61B 音量。
- Kodi on Android/Google TV 可能不具备 libCEC 可控设备路径，Yatse CEC 命令可能无效。
- HTTP 明文凭据只在可信内网发送；不要暴露 Kodi HTTP 端口到互联网。不使用第三方服务器。
- 目前是 **Fold6 手机 App**，不是 Wear OS APK。手表版以后需要独立构建。

## 项目信息

- Package: `com.foldtools.yatsecontrol`
- Main activity: `com.foldtools.yatsecontrol.MainActivity`
- Dependencies: 仅 Android SDK，无第三方运行时依赖
- No ads, no analytics, no cloud
